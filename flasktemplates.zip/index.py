from flask import Flask, render_template

app = Flask(__name__)

moviesArr = ['Avatar', 'Avengers', 'RRR', 'antamn']


@app.route('/')
def hello_world():
    return render_template('index.html', name='rajad')


if __name__ == '__main__':
    app.run(debug=True)
